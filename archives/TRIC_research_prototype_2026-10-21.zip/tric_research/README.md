# TRIC experimental research candidate

An exact, static directed-graph reachability prototype with forward/backward closure certificates and workload-aware pivot selection.

**Not publication-ready or SOTA-validated.** Read [RESEARCH_NOTE.md](RESEARCH_NOTE.md) for the algorithm specification, elementary proofs, experiments, prior-art risks and limitations.

Run:

```bash
python -m unittest -v test_tric.py
python tric.py --output results.json
python benchmark_latency.py
```

Requires standard Python only (3.10+). The distribution and size of all benchmark datasets are generated in `tric.py`. Graphs are synthetic; external code/real-world datasets are not bundled. Graph updates invalidate the stored exact certificates.
